function setup() {
  createCanvas(400, 400);
  background(121)
  ellipse(50,50,75,75) 
  fill(21);
  ellipse(32,40,15,15,);
  fill (220);
  rect(50,300,50,100);
  rect(150,250,50,200);
  rect(300,300,80,150);
  rect(215,200,50,200);
  line(100, 300, 300, 305);
  fill('1')
  noStroke ()
  square(60,315,10);
  square(80,330,10);
  square(60,345,10);
  square(160,315,10);
  square(180,330,10);
  square(160,285,10);
  square(160,345,10);
  square(180,280,10);
  square(160,265,10)
  
  square(225,315,10);
  square(245,330,10);
  square(225,345,10);
  square(225,215,10);
  square(245,230,10);
  square(225,255,10);
  
  square(350,350,10);
  square(310,362,10);
  square(340,370,10);
  square(350,320,10);
  square(310,332,10);
  square(340,310,10);
  
  stroke(220)
  point(300, 20);
  point(185, 50);
  point(165, 75);
  point(100, 75);
  point(260, 25);
  point(265, 50);
  point(165, 75);
  point(95, 200);
  point(190, 35);
  point(185, 45);
  point(165, 55);
  point(30, 95);
  
  strokeWeight(10.0)
  strokeCap(SQUARE);
  line (300,250, 300, 300)
}

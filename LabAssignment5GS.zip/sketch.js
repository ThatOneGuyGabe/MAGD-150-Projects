var value1 = 5
var value2 = 240
var value3 = 83
x=50
y=370
d=60
k=330
l=345
m=50
function setup() {
  createCanvas(400, 400);
  c=1
}

function draw() {
  background(220);
  fill(0);
  square(20,20,360);
  stroke(value1, value2, value3);
  line(mouseX,0,mouseX,400);
  line(0, mouseY, 400, mouseY)
  fill(value1, value2, value3)
  rect(20,80,100,40)
  rect(53,100,35,100)
  rect(20,200,100,40)
  rect(130,80,70,30)
  arc(201.83, 111, 80, 63, 3.2, TWO_PI);
  rect(211.83,108,30,30)
  rect(143,140,25,100)
  rect(130,100,25,140)
  arc(191.83, 136, 100, 63, 0, PI);
  arc(201.83, 181, 100, 63, 3.2, TWO_PI);
  rect(221.83,180,30,30)
  arc(202, 206, 100, 68, 0, PI);
  rect(130,210,66,30)
  strokeWeight(23)
  line(250,230,280,90)
  line(320,230,280,90)
  line(320,230,350,90)
  line(380,230,350,90)




  strokeWeight(1)
  fill(179, 177, 107)
  stroke(179, 177, 107)
  rect(0,0,400,20)
  rect(0,20,20,400)
  rect(0,340,400,600)
  rect(380,20,20,400)
  fill(50)
  ellipse(x,y,d)
  rect(k,l,m,50)
}
function mouseClicked(){
  if (dist(mouseX,mouseY,x,y)<d/2){
    value1=0
    value2=0;
    value3=0;
  } if (dist(mouseX,mouseY,k,l)<m/2){
    value1=5
    value2=240
    value3=83
  }
}